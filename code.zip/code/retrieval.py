import math
import re
from collections import Counter
from typing import Dict, List, Optional, Tuple


class Retriever:
    def __init__(self, message_history_rows: List[Dict[str, str]], message_events_rows: List[Dict[str, str]], similarity_floor: float = 0.55):
        self.history = message_history_rows
        self.events = message_events_rows
        self.similarity_floor = similarity_floor
        self.event_map = {(row.get("user_id"), row.get("message_id")): row for row in self.events}

    def retrieve(self, current_message: Dict[str, str], current_context: Dict[str, object], top_k: int = 2) -> List[Dict[str, object]]:
        candidates = []
        for row in self.history:
            if row.get("user_id") != current_message.get("user_id"):
                continue
            text = (row.get("message_text") or "").strip()
            if not text:
                continue
            sim = self._semantic_similarity(current_message, row)
            if sim < self.similarity_floor:
                continue
            event = self.event_map.get((current_message.get("user_id"), row.get("message_id")), {})
            candidates.append({
                "message_id": row.get("message_id"),
                "snippet": text[:160],
                "similarity": sim,
                "same_sender": self._same_sender(current_message, row),
                "same_group": self._same_group(current_message, row),
                "reaction": self._reaction_summary(event),
                "event": event,
            })
        candidates.sort(key=lambda item: item["similarity"], reverse=True)
        return candidates[:top_k]

    def _semantic_similarity(self, current_message: Dict[str, str], candidate: Dict[str, str]) -> float:
        current_text = self._text_for(current_message)
        cand_text = self._text_for(candidate)
        if not current_text or not cand_text:
            return 0.0
        lexical = self._cosine_similarity(self._tokenize(current_text), self._tokenize(cand_text))
        if lexical > 0.85:
            return 0.95
        # heuristic semantic proxy: shared keywords and contextual term overlap
        keywords_current = set(re.findall(r"[a-zA-Z]{3,}", current_text.lower()))
        keywords_candidate = set(re.findall(r"[a-zA-Z]{3,}", cand_text.lower()))
        if not keywords_current or not keywords_candidate:
            return lexical
        overlap = len(keywords_current & keywords_candidate) / max(1, len(keywords_current | keywords_candidate))
        same_sender = 1.0 if self._same_sender(current_message, candidate) else 0.0
        same_group = 1.0 if self._same_group(current_message, candidate) else 0.0
        # recency weight from created_at if available
        recency = self._recency_weight(current_message.get("created_at"), candidate.get("created_at"))
        score = 0.5 * overlap + 0.2 * same_sender + 0.2 * same_group + 0.1 * recency
        return round(min(1.0, max(0.0, score)), 3)

    def _same_sender(self, current_message: Dict[str, str], candidate: Dict[str, str]) -> bool:
        return bool(current_message.get("sender_user_id") and candidate.get("sender_user_id") and current_message.get("sender_user_id") == candidate.get("sender_user_id"))

    def _same_group(self, current_message: Dict[str, str], candidate: Dict[str, str]) -> bool:
        return bool(current_message.get("group_id") and candidate.get("group_id") and current_message.get("group_id") == candidate.get("group_id"))

    def _recency_weight(self, current_time: Optional[str], candidate_time: Optional[str]) -> float:
        if not current_time or not candidate_time:
            return 0.5
        try:
            from datetime import datetime
            a = datetime.strptime(current_time, "%Y-%m-%d %H:%M")
            b = datetime.strptime(candidate_time, "%Y-%m-%d %H:%M")
            delta = abs((a - b).total_seconds()) / 3600.0
            if delta <= 24:
                return 1.0
            if delta <= 72:
                return 0.7
            return 0.3
        except Exception:
            return 0.5

    def _text_for(self, message: Dict[str, str]) -> str:
        text = (message.get("message_text") or "").strip()
        if not text:
            text = message.get("unified_text") or ""
        return re.sub(r"\s+", " ", text).lower()

    def _tokenize(self, text: str) -> Counter:
        return Counter(re.findall(r"[a-zA-Z]{2,}", text.lower()))

    def _cosine_similarity(self, a: Counter, b: Counter) -> float:
        if not a or not b:
            return 0.0
        dot = sum((a & b).values())
        norm = math.sqrt(sum(v * v for v in a.values())) * math.sqrt(sum(v * v for v in b.values()))
        if norm == 0:
            return 0.0
        return round(dot / norm, 3)

    def _reaction_summary(self, event: Dict[str, str]) -> str:
        if not event:
            return "none"
        opened = event.get("message_opened") == "1"
        replied = event.get("message_replied") == "1"
        dismissed = event.get("notification_dismissed") == "1"
        reported = event.get("message_reported") == "1"
        if reported:
            return "reported"
        if opened and replied:
            return "opened_replied"
        if opened:
            return "opened"
        if dismissed:
            return "dismissed"
        if replied:
            return "replied"
        return "seen"
